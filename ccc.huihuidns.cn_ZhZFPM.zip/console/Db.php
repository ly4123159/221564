<?php

// 数据库操作类
include 'DbClass.php';

// 数据库配置
$config = [
    'db_host' => '127.0.0.1',
    'db_port' => 3306,
    'db_name' => 'ccc_huihuidns_cn',
    'db_user' => 'ccc_huihuidns_cn',
    'db_pass' => 'Jke2NCbsm254hZiH',
    'folderNum' => '1',
    'db_prefix' => ''
];
?>